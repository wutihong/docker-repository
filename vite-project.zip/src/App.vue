<template>
  <router-view/>
</template>

<style>
html,
body,
#app {
  width: 100%;
  height: 100%;
}
</style>
